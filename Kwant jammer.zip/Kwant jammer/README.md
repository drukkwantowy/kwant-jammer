Kwantowy jammer do blokowania techniki kwantowej sygnał wygenerowany
z kodu drukarki kwantowej na pewnej czestsotliwości może skutecznie
teleportacją kwantową blokować technologie kwantowe wystarczy 
zmienić linijke kodu dopisać do jamera i zakres czestotliwości która zostanie
wygenerowana aby blokować kantowe technologie przy użyciu programu i anteny
czyli wszelkie technologie UFO będą spadać na ziemie jak pociski po deszczu
meteorów a technologie kwantowe nie będą magiczne i będą na złom.
Dobrze wygenerowany sygnał kwantowy jest w stanie blokować kwanty jak i
płynny metal. Wyposarzając go w SI osoba która włada kwantami zostanie
gentycznie zablokowana i będzie operować mechaniczną fizyką. 

